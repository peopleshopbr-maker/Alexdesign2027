/* tslint:disable */
/* eslint-disable */

export function analyze_mesh_bounds(input: any): any;

export function evaluate_scene_frame(scene_data: any, time_sec: number): any;

export function generate_blender_vfx_script(scene_data: any, glb_filename: string): string;

export function generate_rigged_animation_glb(scene_data: any, clip_type?: string | null): Uint8Array;

export function get_animation_clip_types(): any;
