/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const analyze_mesh_bounds: (a: any) => [number, number, number];
export const evaluate_scene_frame: (a: any, b: number) => [number, number, number];
export const generate_blender_vfx_script: (a: any, b: number, c: number) => [number, number, number, number];
export const generate_rigged_animation_glb: (a: any, b: number, c: number) => [number, number, number, number];
export const get_animation_clip_types: () => [number, number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
