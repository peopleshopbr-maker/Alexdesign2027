/* @ts-self-types="./wasm_core.d.ts" */
import * as wasm from "./wasm_core_bg.wasm";
import { __wbg_set_wasm } from "./wasm_core_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    analyze_mesh_bounds, evaluate_scene_frame, generate_blender_vfx_script, generate_rigged_animation_glb, get_animation_clip_types
} from "./wasm_core_bg.js";
